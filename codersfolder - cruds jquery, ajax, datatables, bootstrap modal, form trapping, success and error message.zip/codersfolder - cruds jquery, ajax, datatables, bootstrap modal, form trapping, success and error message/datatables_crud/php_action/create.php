<?php 

require_once 'db_connect.php';

//if form is submitted
if($_POST) {	

	$validator = array('success' => false, 'messages' => array()); //this is the variable for success or error message when form submit
																   //naa sa ubos iyang code kanang if and else
	$name = $_POST['name'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$active = $_POST['active'];

	$sql = "INSERT INTO members (name, contact, address, active) VALUES ('$name', '$contact', '$address', '$active')";
	$query = $connect->query($sql);  //$connect is from the database ma access siya kay naka require_once man

	if($query === TRUE) {			
		$validator['success'] = true;
		$validator['messages'] = "Successfully Added";		
	} else {		
		$validator['success'] = false;
		$validator['messages'] = "Error while adding the member information";
	}

	// close the database connection
	$connect->close();

	echo json_encode($validator); //isulod ang data sa json

}